global.UUID = require("uuidjs");
global.UUIDTestCommon = require("./util/uuid-test-common.js");

require("./uuid.generate.js");
require("./uuid.genV4.js");
require("./uuid.genV1.js");
require("./uuid.parse.js");
require("./uuid.nil.js");
require("./uuid.useMathRandom.js");
